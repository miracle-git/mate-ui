# `@mate-ui/web`

> TODO: description

## Usage

```
const web = require('@mate-ui/web');

// TODO: DEMONSTRATE API
```
