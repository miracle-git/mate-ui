'use strict';

const web = require('..');

describe('@mate-ui/web', () => {
    it('needs tests');
});
