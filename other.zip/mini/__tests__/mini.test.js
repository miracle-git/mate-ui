'use strict';

const mini = require('..');

describe('@mate-ui/mini', () => {
    it('needs tests');
});
