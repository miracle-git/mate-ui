# `@mate-ui/mini`

> TODO: description

## Usage

```
const mini = require('@mate-ui/mini');

// TODO: DEMONSTRATE API
```
