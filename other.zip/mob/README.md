# `@mate-ui/mob`

> TODO: description

## Usage

```
const mob = require('@mate-ui/mob');

// TODO: DEMONSTRATE API
```
