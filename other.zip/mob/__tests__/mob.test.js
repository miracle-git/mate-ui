'use strict';

const mob = require('..');

describe('@mate-ui/mob', () => {
    it('needs tests');
});
