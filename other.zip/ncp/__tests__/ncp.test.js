'use strict';

const ncp = require('..');

describe('@mate-ui/ncp', () => {
    it('needs tests');
});
