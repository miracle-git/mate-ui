# `@mate-ui/ncp`

> TODO: description

## Usage

```
const ncp = require('@mate-ui/ncp');

// TODO: DEMONSTRATE API
```
