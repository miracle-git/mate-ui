# `@mate-ui/icon`

> TODO: description

## Usage

```
const icon = require('@mate-ui/icon');

// TODO: DEMONSTRATE API
```
