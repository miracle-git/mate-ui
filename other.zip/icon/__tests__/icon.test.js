'use strict';

const icon = require('..');

describe('@mate-ui/icon', () => {
    it('needs tests');
});
